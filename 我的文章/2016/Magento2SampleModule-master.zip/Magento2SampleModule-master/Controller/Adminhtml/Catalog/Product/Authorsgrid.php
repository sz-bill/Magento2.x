<?php
namespace Sample\News\Controller\Adminhtml\Catalog\Product;

use Magento\Catalog\Controller\Adminhtml\Product\Edit;

class Authorsgrid extends Authors
{
    
}
