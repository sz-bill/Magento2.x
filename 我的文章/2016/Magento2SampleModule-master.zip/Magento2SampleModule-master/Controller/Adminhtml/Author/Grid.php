<?php
namespace Sample\News\Controller\Adminhtml\Author;

class Grid extends Index
{
    /**
     * set page data
     *
     * @return $this
     */
    public function setPageData()
    {
        return $this;
    }
}
