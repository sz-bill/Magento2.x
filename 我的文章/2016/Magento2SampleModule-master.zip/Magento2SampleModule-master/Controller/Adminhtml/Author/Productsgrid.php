<?php
namespace Sample\News\Controller\Adminhtml\Author;

use Sample\News\Controller\Adminhtml\Author\Products;

class Productsgrid extends Products
{

}
