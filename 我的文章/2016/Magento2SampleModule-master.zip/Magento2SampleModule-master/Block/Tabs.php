<?php
namespace Sample\News\Block;

use Magento\Framework\View\Element\Template;

class Tabs extends Template
{

}