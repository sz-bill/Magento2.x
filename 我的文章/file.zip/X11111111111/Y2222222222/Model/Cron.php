<?php
/**
 * Copyright © 2015 X11111111111. All rights reserved.
 */

namespace X11111111111\Y2222222222\Model;

class Cron extends \Magento\Framework\Model\AbstractModel
{

    public function methodName()
    {
        return $this;
    }
}
