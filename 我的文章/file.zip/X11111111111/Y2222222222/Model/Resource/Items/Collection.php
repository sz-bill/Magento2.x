<?php
/**
 * Copyright © 2015 X11111111111. All rights reserved.
 */

namespace X11111111111\Y2222222222\Model\Resource\Items;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('X11111111111\Y2222222222\Model\Items', 'X11111111111\Y2222222222\Model\Resource\Items');
    }
}
