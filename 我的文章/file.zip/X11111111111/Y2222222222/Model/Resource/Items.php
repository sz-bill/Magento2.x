<?php
/**
 * Copyright © 2015 X11111111111. All rights reserved.
 */

namespace X11111111111\Y2222222222\Model\Resource;

class Items extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Model Initialization
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('x11111111111_y2222222222_items', 'id');
    }
}
