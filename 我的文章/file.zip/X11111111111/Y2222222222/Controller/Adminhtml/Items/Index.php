<?php
/**
 * Copyright © 2015 X11111111111. All rights reserved.
 */

namespace X11111111111\Y2222222222\Controller\Adminhtml\Items;

class Index extends \X11111111111\Y2222222222\Controller\Adminhtml\Items
{
    /**
     * Items list.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('X11111111111_Y2222222222::y2222222222');
        $resultPage->getConfig()->getTitle()->prepend(__('X11111111111 Items'));
        $resultPage->addBreadcrumb(__('X11111111111'), __('X11111111111'));
        $resultPage->addBreadcrumb(__('Items'), __('Items'));
        return $resultPage;
    }
}
