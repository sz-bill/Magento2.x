<?php
/**
 * Copyright © 2015 X11111111111. All rights reserved.
 */

namespace X11111111111\Y2222222222\Controller\Adminhtml\Items;

class NewAction extends \X11111111111\Y2222222222\Controller\Adminhtml\Items
{

    public function execute()
    {
        $this->_forward('edit');
    }
}
