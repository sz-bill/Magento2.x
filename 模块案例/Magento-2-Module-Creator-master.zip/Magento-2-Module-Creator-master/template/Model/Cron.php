<?php
/**
 * Copyright © 2015 {{CompanyName}}. All rights reserved.
 */

namespace {{CompanyName}}\{{ModuleName}}\Model;

class Cron extends \Magento\Framework\Model\AbstractModel
{

    public function methodName()
    {
        return $this;
    }
}
