<?php
/**
 * Copyright © 2015 DevelopLabel. All rights reserved.
 */
namespace DevelopLabel\Demo\Model\ResourceModel;

/**
 * H2w resource
 */
class H2w extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init('demo_h2w', 'id');
    }

  
}
