<?php
/**
 * Copyright © 2015 DevelopLabel . All rights reserved.
 */
namespace DevelopLabel\Demo\Block\HelloWorld;
use DevelopLabel\Demo\Block\BaseBlock;
class Index extends BaseBlock
{
	public $hello='Hello World';
	
}
