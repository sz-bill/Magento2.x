<?php
namespace DevelopLabel\Demo\Block\Adminhtml\H2w\Edit;

class Tabs extends \Magento\Backend\Block\Widget\Tabs
{
    protected function _construct()
    {
		
        parent::_construct();
        $this->setId('checkmodule_h2w_tabs');
        $this->setDestElementId('edit_form');
        $this->setTitle(__('H2w Information'));
    }
}