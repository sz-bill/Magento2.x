<?php
namespace DevelopLabel\Demo\Block\Adminhtml;
class H2w extends \Magento\Backend\Block\Widget\Grid\Container
{
    /**
     * Constructor
     *
     * @return void
     */
    protected function _construct()
    {
		
        $this->_controller = 'adminhtml_h2w';/*block grid.php directory*/
        $this->_blockGroup = 'DevelopLabel_Demo';
        $this->_headerText = __('H2w');
        $this->_addButtonLabel = __('Add New Entry'); 
        parent::_construct();
		
    }
}