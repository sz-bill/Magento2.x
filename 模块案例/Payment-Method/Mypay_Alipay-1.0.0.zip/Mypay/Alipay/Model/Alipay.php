<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mypay\Alipay\Model;



/**
 * Pay In Store payment method model
 */
class Alipay extends \Magento\Payment\Model\Method\AbstractMethod
{

    /**
     * Payment code
     *
     * @var string
     */
    protected $_code = 'alipay';

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_isOffline = true;


  

}
